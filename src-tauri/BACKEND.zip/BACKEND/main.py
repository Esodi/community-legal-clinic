from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from db import init_db
from auth.routes import router as auth_router
from service.routes import router as services_router
from testimonial.routes import router as testimonials_router
from hero.routes import router as hero_router
from company.routes import router as company_router
from announcements.routes import router as announcements_router
from how.routes import router as how_router
from webpages.routes import router as webpages_router
import json
import os
import asyncio
from typing import Set, Dict, Optional
from datetime import datetime, timedelta
import signal
import sys
import logging
import jwt
from pydantic import BaseModel
from webpages.routes import web_data
# JWT Configuration
JWT_SECRET_KEY = "your-super-secret-key-keep-it-safe"  # In production, use environment variable
JWT_ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class TokenData(BaseModel):
    username: str
    role: str = "user"
    exp: Optional[datetime] = None

def create_access_token(data: dict) -> str:
    """
    Create a new JWT access token
    """
    try:
        to_encode = data.copy()
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        to_encode.update({"exp": expire})
        encoded_jwt = jwt.encode(to_encode, JWT_SECRET_KEY, algorithm=JWT_ALGORITHM)
        logger.info(f"Created token for user: {data.get('username')}")
        return encoded_jwt
    except Exception as e:
        logger.error(f"Error creating token: {str(e)}")
        raise HTTPException(status_code=500, detail="Could not create token")

def verify_token(token: str) -> Optional[dict]:
    """
    Verify a JWT token and return its payload if valid
    """
    try:
        payload = jwt.decode(token, JWT_SECRET_KEY, algorithms=[JWT_ALGORITHM])
        username: str = payload.get("username")
        role: str = payload.get("role", "user")
        
        if username is None:
            logger.warning("Token missing username")
            return None
            
        token_data = TokenData(
            username=username,
            role=role,
            exp=datetime.fromtimestamp(payload.get("exp"))
        )
        logger.info(f"Token verified for user: {username}")
        return payload
        
    except jwt.ExpiredSignatureError:
        logger.warning("Token has expired")
        return None
    except jwt.JWTError as e:
        logger.warning(f"Invalid token: {str(e)}")
        return None
    except Exception as e:
        logger.error(f"Error verifying token: {str(e)}")
        return None

app = FastAPI()

# Initialize SQLite database
init_db()

# CORS configuration
origins = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "http://localhost:3001",  # Added for when port 3000 is in use
    "http://127.0.0.1:3001",
    "http://localhost:8000",
    "http://0.0.0.0:8000",
    "http://0.0.0.0:8000",
    "*"  # For development only, remove in production
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include all routes
app.include_router(auth_router, prefix="/auth", tags=["auth"])
app.include_router(services_router, prefix="/services", tags=["services"])
app.include_router(testimonials_router, prefix="/testimonials", tags=["testimonials"])
app.include_router(hero_router, prefix="/hero", tags=["hero"])
app.include_router(company_router, prefix="/company-details", tags=["company-details"])
app.include_router(announcements_router, prefix="/announcements", tags=["announcements"])
app.include_router(how_router, prefix="/how", tags=["how"])
app.include_router(webpages_router, prefix="/webpages", tags=["webpages"])

@app.get("/generate-test-token")
async def generate_test_token():
    """
    Generate a test token for development purposes
    """
    try:
        token_data = {
            "username": "test_user",
            "role": "user",
            "sub": "test_user"
        }
        token = create_access_token(token_data)
        logger.info("Generated test token successfully")
        return JSONResponse(content={"token": token})
    except Exception as e:
        logger.error(f"Error generating test token: {str(e)}")
        raise HTTPException(status_code=500, detail="Could not generate test token")

@app.get("/status")
async def root():
    """
    Root endpoint to check server status
    """
    status = {
        "status": "online",
        "time": datetime.now().isoformat()
    }

    return status

# Connection manager class definition...
class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}
        self.connection_count = 0

    async def connect(self, websocket: WebSocket) -> str:
        try:
            await websocket.accept()
            connection_id = f"conn_{self.connection_count}"
            self.active_connections[connection_id] = websocket
            self.connection_count += 1
            logger.info(f"Client connected. ID: {connection_id}. Total connections: {len(self.active_connections)}")
            return connection_id
        except Exception as e:
            logger.error(f"Error accepting connection: {str(e)}")
            raise

    def disconnect(self, connection_id: str):
        try:
            if connection_id in self.active_connections:
                del self.active_connections[connection_id]
                logger.info(f"Client {connection_id} disconnected. Total connections: {len(self.active_connections)}")
        except Exception as e:
            logger.error(f"Error during disconnect of {connection_id}: {str(e)}")

    async def send_personal_message(self, message: dict | str, connection_id: str):
        if connection_id in self.active_connections:
            websocket = self.active_connections[connection_id]
            try:
                if isinstance(message, dict):
                    await websocket.send_json(message)
                    logger.debug(f"Sent JSON message to {connection_id}")
                elif isinstance(message, str):
                    await websocket.send_text(message)
                    logger.debug(f"Sent text message to {connection_id}")
                else:
                    logger.warning(f"Invalid message type for {connection_id}: {type(message)}")
            except Exception as e:
                logger.error(f"Error sending message to {connection_id}: {str(e)}")
                self.disconnect(connection_id)

# Create manager instance
manager = ConnectionManager()

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    connection_id = await manager.connect(websocket)
    
    try:
        # Send immediate connection acknowledgment
        await manager.send_personal_message(
            {"type": "connection", "status": "connected", "message": "Waiting for authentication"},
            connection_id
        )
        
        # Wait for authentication
        auth_timeout = 30  # 30 seconds to authenticate
        try:
            message = await asyncio.wait_for(websocket.receive_text(), timeout=auth_timeout)
            auth_result = await handle_client_message(websocket, message, connection_id)
            if not auth_result:
                logger.warning(f"User not found for {connection_id}")
                return
            logger.info(f"Client {connection_id} completed authentication")
        except asyncio.TimeoutError:
            await manager.send_personal_message(
                {"type": "error", "message": "Authentication timeout"},
                connection_id
            )
            logger.warning(f"Authentication timeout for {connection_id}")
            return

        # Keep connection alive and handle updates
        while True:
            try:
                message = await asyncio.wait_for(websocket.receive_text(), timeout=30.0)
                continue_processing = await handle_client_message(websocket, message, connection_id)
                if not continue_processing:
                    break
            except asyncio.TimeoutError:
                try:
                    await manager.send_personal_message({"type": "ping"}, connection_id)
                except Exception as e:
                    logger.error(f"Connection lost for {connection_id}: {str(e)}")
                    break
            except WebSocketDisconnect:
                logger.info(f"Client {connection_id} disconnected normally")
                break
            except Exception as e:
                logger.error(f"Error in message loop for {connection_id}: {str(e)}")
                break
            
    except Exception as e:
        logger.error(f"WebSocket error for {connection_id}: {str(e)}")
    finally:
        manager.disconnect(connection_id)

async def handle_client_message(websocket: WebSocket, message: str, connection_id: str) -> bool:
    try:
        msg_data = json.loads(message)
        msg_type = msg_data.get("type", "")
        logger.info(f"Received message type '{msg_type}' from {connection_id}")

        if msg_type == "auth":
            token = msg_data.get("token")
            if token:
                payload = verify_token(token)
                if payload:
                    await manager.send_personal_message(
                        {"type": "auth", "status": "success", "userId": payload.get("sub")},
                        connection_id
                    )
                    logger.info(f"Client {connection_id} authenticated successfully")
                    return True
            await manager.send_personal_message(
                {"type": "auth", "status": "error", "message": "Invalid token"},
                connection_id
            )
            logger.warning(f"Client {connection_id} failed authentication")
            return False
        
        elif msg_type == "ping":
            await manager.send_personal_message({"type": "pong"}, connection_id)
            logger.debug(f"Sent pong to {connection_id}")
        elif msg_type == "getData":
            #data = await get_all_data()
            data = await web_data()
            with open('data_sent.json', 'w', encoding='utf-8') as file:
                json.dump(data, file)
            logger.info("Data saved to data_sent.json")
            await manager.send_personal_message({"type": "data", "data": data}, connection_id)
            logger.info(f"Sent data to {connection_id}")
        return True
    except json.JSONDecodeError:
        await manager.send_personal_message(
            {"type": "error", "message": "Invalid JSON"},
            connection_id
        )
        logger.error(f"Invalid JSON received from {connection_id}")
        return True
    except Exception as e:
        logger.error(f"Error handling message from {connection_id}: {str(e)}")
        return False

# Load JSON data function...
def load_json_data(filename: str) -> dict:
    try:
        filepath = os.path.join(os.path.dirname(__file__), 'data', filename)
        if not os.path.exists(filepath):
            logger.warning(f"File not found: {filepath}")
            return {}
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
            logger.debug(f"Successfully loaded {filename}")
            return data
    except Exception as e:
        logger.error(f"Error loading {filename}: {str(e)}")
        return {}

# Create data directory if it doesn't exist
data_dir = os.path.join(os.path.dirname(__file__), 'data')
os.makedirs(data_dir, exist_ok=True)

async def get_all_data() -> dict:
    logger.debug("Fetching all data")
    try:
        return {
            "heroData": load_json_data('hero.json'),
            "servicesData": load_json_data('services.json'),
            "howData": load_json_data('how.json'),
            "announcementsData": load_json_data('announcements.json'),
            "footerData": load_json_data('footer.json'),
            "testimonialsData": load_json_data('testimonials.json'),
            "headerData": load_json_data('header.json'),
            "usersData": load_json_data('users.json')
        }
    except Exception as e:
        logger.error(f"Error getting all data: {str(e)}")
        return {}

def handle_shutdown(signum, frame):
    logger.info("Shutting down server...")
    # Close all active connections
    for conn_id in list(manager.active_connections.keys()):
        try:
            manager.disconnect(conn_id)
        except:
            pass
    sys.exit(0)

# Register shutdown handlers
signal.signal(signal.SIGINT, handle_shutdown)
signal.signal(signal.SIGTERM, handle_shutdown)

if __name__ == "__main__":
    import uvicorn
    logger.info("Starting server...")
    logger.info(f"Data directory: {data_dir}")
    logger.info(f"WebSocket endpoint: ws://localhost:8000/ws")
    
    config = uvicorn.Config(
        app=app,
        host="0.0.0.0",
        port=8000,
        log_level="info",
        access_log=True,
        timeout_keep_alive=30,
        ws_ping_interval=20,
        ws_ping_timeout=30,
        reload=True,  # Enable auto-reload for development
        reload_dirs=["BACKEND"],  # Watch the BACKEND directory for changes
        reload_includes=["*.py", "*.json"],  # Watch Python and JSON files
        reload_excludes=["*.pyc", "*.pyo", "__pycache__"]  # Exclude cache files
    )
    server = uvicorn.Server(config)
    server.run() 