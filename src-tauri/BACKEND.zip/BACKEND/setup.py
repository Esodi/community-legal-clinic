from setuptools import setup, find_packages

setup(
    name="dashboard-backend",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "fastapi==0.109.0",
        "uvicorn[standard]==0.27.0",
        "websockets==12.0",
        "python-dotenv==1.0.0",
        "starlette==0.36.3",
        "sqlalchemy==2.0.25",
        "pyjwt==2.8.0",
        "passlib[bcrypt]==1.7.4",
        "python-multipart==0.0.6",
        "email-validator==2.1.0.post1"
    ],
) 