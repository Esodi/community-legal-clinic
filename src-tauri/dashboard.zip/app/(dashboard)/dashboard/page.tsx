"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import LoadingSpinner from "@/components/LoadingSpinner"

interface User {
  id: number
  username: string
  email: string
  role: string
  createdAt: string
}

export default function DashboardPage() {
  const router = useRouter()
  const [userData, setUserData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    // Get user data from localStorage
    const userStr = localStorage.getItem("user")
    if (userStr) {
      try {
        const user = JSON.parse(userStr)
        setUserData(user)
      } catch (err) {
        console.error("Error parsing user data:", err)
      }
    }
    setLoading(false)
  }, [])

  if (loading) {
    return (
        <LoadingSpinner />
    )
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="text-red-600 dark:text-red-400">{error}</div>
      </div>
    )
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold">Welcome, {userData?.username || 'User'}!</h1>
        <div className="text-sm text-gray-600 dark:text-gray-400">
          {new Date().toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <div className="p-6 bg-white dark:bg-[#1F1F23] rounded-lg shadow">
          <h2 className="text-lg font-semibold mb-2">Total Balance</h2>
          <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">$45,250.00</p>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">+12.5% from last month</p>
        </div>
        <div className="p-6 bg-white dark:bg-[#1F1F23] rounded-lg shadow">
          <h2 className="text-lg font-semibold mb-2">Active Investments</h2>
          <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">12</p>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">Across 4 categories</p>
        </div>
        <div className="p-6 bg-white dark:bg-[#1F1F23] rounded-lg shadow">
          <h2 className="text-lg font-semibold mb-2">Total Returns</h2>
          <p className="text-3xl font-bold text-green-600">+15.4%</p>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">Year to date</p>
        </div>
      </div>

      <div className="mt-6 p-6 bg-white dark:bg-[#1F1F23] rounded-lg shadow">
        <h2 className="text-lg font-semibold mb-4">Recent Transactions</h2>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-[#2D2D33] rounded-lg">
            <div>
              <p className="font-medium">Investment Deposit</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Mar 15, 2024</p>
            </div>
            <p className="text-green-600 font-medium">+$5,000.00</p>
          </div>
          <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-[#2D2D33] rounded-lg">
            <div>
              <p className="font-medium">Withdrawal</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Mar 14, 2024</p>
            </div>
            <p className="text-red-600 font-medium">-$1,200.00</p>
          </div>
          <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-[#2D2D33] rounded-lg">
            <div>
              <p className="font-medium">Investment Return</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">Mar 13, 2024</p>
            </div>
            <p className="text-green-600 font-medium">+$750.00</p>
          </div>
        </div>
      </div>
    </div>
  )
} 