"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Sidebar from "@/components/kokonutui/sidebar"
import TopNav from "@/components/kokonutui/topnav"
import LoadingSpinner from "@/components/LoadingSpinner"
interface User {
  id?: string
  username: string
  email?: string
  role: "admin" | "user"
}

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()
  const [userData, setUserData] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        setIsLoading(true)
        
        // First try to get data from cookies
        const isAuthenticatedCookie = document.cookie
          .split('; ')
          .find(row => row.startsWith('isAuthenticated='))
          ?.split('=')[1];
          
        // If we have an authenticated cookie, try to fetch user data from API
        if (isAuthenticatedCookie === 'true') {
          // Try to fetch user data from API
          const response = await fetch('/api/auth/user', {
            credentials: 'include'
          });
          
          if (response.ok) {
            const data = await response.json();
            setUserData(data);
            
            // Also store in localStorage for other components
            localStorage.setItem('user', JSON.stringify(data));
          } else {
            // If API fails, create a basic user object from cookies
            const username = document.cookie
              .split('; ')
              .find(row => row.startsWith('username='))
              ?.split('=')[1];
              
            if (username) {
              const basicUser = {
                username: username,
                role: "user" as const
              };
              setUserData(basicUser);
              localStorage.setItem('user', JSON.stringify(basicUser));
            } else {
              throw new Error('No user data available');
            }
          }
        } else {
          // Try to load user data from localStorage as fallback
          const userStr = localStorage.getItem('user');
          if (userStr) {
            const user = JSON.parse(userStr);
            setUserData(user);
          } else {
            throw new Error('No user data available');
          }
        }
      } catch (error) {
        console.error('Error getting user data:', error);
        router.push('/login');
      } finally {
        setIsLoading(false);
      }
    };

    fetchUserData();
  }, [router]);

  // Show loading state while fetching user data
  if (isLoading || !userData) {
    return <LoadingSpinner />
  }

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-[#0A0A0C]">
      <Sidebar userRole={userData.role} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopNav userData={userData} />
        <main className="flex-1 overflow-y-auto">
          <div className="">
            {children}
          </div>
        </main>
      </div>
    </div>
  )
} 