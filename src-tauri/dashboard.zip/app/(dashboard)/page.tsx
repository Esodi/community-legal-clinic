"use client"

import { useEffect, useState } from "react"

interface User {
  id: string
  username: string
  email: string
  role: string
  createdAt: string
}

export default function HomePage() {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [debugInfo, setDebugInfo] = useState<any>(null)
  const [showDebug, setShowDebug] = useState(false)
  const [currentUser, setCurrentUser] = useState<any>(null)

  async function testConnection() {
    try {
      const response = await fetch("/api/test")
      const data = await response.json()
      setDebugInfo({
        test: data,
        cookies: document.cookie,
        timestamp: new Date().toISOString()
      })
    } catch (err) {
      setDebugInfo({
        error: err instanceof Error ? err.message : String(err),
        cookies: document.cookie,
        timestamp: new Date().toISOString()
      })
    }
  }

  useEffect(() => {
    // Get current user from localStorage
    const userStr = localStorage.getItem("user")
    if (userStr) {
      try {
        const user = JSON.parse(userStr)
        setCurrentUser(user)
      } catch (err) {
        console.error("Error parsing user data:", err)
      }
    }
  }, [])

  useEffect(() => {
    async function fetchUsers() {
      try {
        setLoading(true)
        console.log("Fetching users...")
        const response = await fetch("/api/users", {
          method: "GET",
          headers: {
            "Content-Type": "application/json"
          },
          credentials: "include" // Important for cookies
        })
        
        if (!response.ok) {
          console.error("Error response:", response.status, response.statusText)
          throw new Error(`Failed to fetch users: ${response.status}`)
        }
        
        const data = await response.json()
        console.log("Fetched users:", data)
        
        if (Array.isArray(data)) {
          setUsers(data)
        } else {
          console.error("Unexpected data format:", data)
          setError("Received invalid data format from server")
        }
      } catch (err) {
        console.error("Error fetching users:", err)
        setError(err instanceof Error ? err.message : "Failed to load users")
      } finally {
        setLoading(false)
      }
    }

    fetchUsers()
  }, [])


  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen">
        <div className="text-red-600 dark:text-red-400 mb-4">{error}</div>
        <button
          onClick={testConnection}
          className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          Test API Connection
        </button>
        {debugInfo && (
          <div className="mt-4 max-w-lg bg-gray-100 dark:bg-gray-800 p-4 rounded overflow-auto text-xs">
            <pre>{JSON.stringify(debugInfo, null, 2)}</pre>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">
        Welcome, {currentUser?.username || "User"}!
      </h1>

      <div className="mb-6 flex justify-between items-center">
        <button
          onClick={() => setShowDebug(!showDebug)}
          className="text-xs px-2 py-1 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded"
        >
          {showDebug ? "Hide Debug" : "Show Debug"}
        </button>
        
        <button
          onClick={testConnection}
          className="text-xs px-2 py-1 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 rounded"
        >
          Test API
        </button>
      </div>

      {showDebug && debugInfo && (
        <div className="mb-6 bg-gray-100 dark:bg-gray-800 p-4 rounded overflow-auto text-xs">
          <pre>{JSON.stringify(debugInfo, null, 2)}</pre>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-6 shadow-sm">
          <h2 className="font-semibold text-gray-900 dark:text-white mb-2">Total Balance</h2>
          <p className="text-3xl font-bold text-blue-500">$45,250.00</p>
          <p className="text-sm text-green-600">+12.5% from last month</p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-6 shadow-sm">
          <h2 className="font-semibold text-gray-900 dark:text-white mb-2">Active Investments</h2>
          <p className="text-3xl font-bold text-blue-500">12</p>
          <p className="text-sm text-gray-500 dark:text-gray-400">Across 4 categories</p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-6 shadow-sm">
          <h2 className="font-semibold text-gray-900 dark:text-white mb-2">Total Returns</h2>
          <p className="text-3xl font-bold text-green-500">+15.3%</p>
          <p className="text-sm text-gray-500 dark:text-gray-400">Year to date</p>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden">
        <div className="px-6 py-4">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            Recent Transactions
          </h2>
        </div>
        
        <div className="border-t border-gray-200 dark:border-gray-700">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-800">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Date</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Description</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Amount</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">May 4, 2023</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">Stock Purchase - AAPL</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600">-$2,250.00</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Completed</span>
                </td>
              </tr>
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">May 2, 2023</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">Dividend Payment</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600">+$375.42</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Completed</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="mt-8 bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden">
        <div className="px-6 py-4">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            Registered Users
          </h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            {users.length} users found
          </p>
        </div>
        <div className="border-t border-gray-200 dark:border-gray-700">
          {users.length === 0 ? (
            <div className="p-6 text-center text-gray-500 dark:text-gray-400">
              No users found
            </div>
          ) : (
            <ul className="divide-y divide-gray-200 dark:divide-gray-700">
              {users.map((user) => (
                <li key={user.id} className="px-6 py-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                        {user.username}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400 truncate">
                        {user.email}
                      </p>
                    </div>
                    <div className="ml-4 flex-shrink-0">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                        {user.role}
                      </span>
                    </div>
                  </div>
                  <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                    Joined {new Date(user.createdAt).toLocaleDateString()}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  )
} 