"use client"

import { useState, useEffect } from "react"
import { useForm, useFieldArray } from "react-hook-form"
import LoadingSpinner from "@/components/LoadingSpinner"
interface Date {
  day: string
  month: string
  year: string
}

interface Announcement {
  id: number
  title: string
  description: string
  date: Date
  isNew: boolean
}

interface AnnouncementsData {
  title: string
  announcements: Announcement[]
}

export default function AnnouncementsPage() {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [isSaving, setIsSaving] = useState(false)
  const [saveSuccess, setSaveSuccess] = useState(false)
  const { register, handleSubmit, reset, control } = useForm<AnnouncementsData>({
    defaultValues: {
      title: "ANNOUNCEMENTS",
      announcements: []
    }
  })

  const { fields, append, remove } = useFieldArray({
    control,
    name: "announcements"
  })

  useEffect(() => {
    fetchAnnouncements()
  }, [])

  async function fetchAnnouncements() {
    try {
      setLoading(true)
      setError("")
      
      const response = await fetch("/api/announcements", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        }
      })
      
      if (!response.ok) {
        console.error("Failed to fetch announcements:", response.status, response.statusText)
        throw new Error(`Failed to load announcements: ${response.status}`)
      }
      
      const data = await response.json()
      
      // If we get valid data, reset the form with it
      if (data && (data.announcements || data.title)) {
        reset({
          title: data.title || "ANNOUNCEMENTS",
          announcements: Array.isArray(data.announcements) ? data.announcements : []
        })
      } else {
        // Initialize with empty data if response format is unexpected
        reset({
          title: "ANNOUNCEMENTS",
          announcements: []
        })
      }
    } catch (err) {
      console.error("Fetch error:", err)
      setError(err instanceof Error ? err.message : "Failed to load announcements")
    } finally {
      setLoading(false)
    }
  }

  async function onSubmit(data: AnnouncementsData) {
    try {
      setIsSaving(true)
      setSaveSuccess(false)
      setError("")
      
      // Save each announcement individually
      for (const announcement of data.announcements) {
        if (announcement.id) {
          // Update existing announcement
          await fetch(`/api/announcements`, {
            method: "PUT",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              id: announcement.id,
              title: announcement.title,
              description: announcement.description,
              date: announcement.date,
              isNew: announcement.isNew
            }),
          })
        } else {
          // Create new announcement
          await fetch(`/api/announcements`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              title: announcement.title,
              description: announcement.description,
              date: announcement.date,
              isNew: announcement.isNew
            }),
          })
        }
      }
      
      setSaveSuccess(true)
      // Refresh the announcements data
      fetchAnnouncements()
    } catch (err) {
      console.error("Submit error:", err)
      setError(err instanceof Error ? err.message : "Failed to save announcements")
    } finally {
      setIsSaving(false)
    }
  }

  function handleAddAnnouncement() {
    append({
      id: 0, // Use 0 for new announcements
      title: "",
      description: "",
      date: {
        day: new Date().getDate().toString(),
        month: new Date().toLocaleString('default', { month: 'short' }),
        year: new Date().getFullYear().toString()
      },
      isNew: true
    })
  }

  if (loading) {
    return (
        <LoadingSpinner />
    )
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Manage Announcements</h1>

      {error && (
        <div className="mb-6 p-4 border border-red-500 bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300 rounded-lg">
          <p className="font-medium">Error</p>
          <p>{error}</p>
          <button 
            onClick={fetchAnnouncements}
            className="mt-2 px-3 py-1 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
          >
            Try Again
          </button>
        </div>
      )}

      {saveSuccess && (
        <div className="mb-6 p-4 border border-green-500 bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-300 rounded-lg">
          <p>Announcements saved successfully!</p>
        </div>
      )}

      <div className="bg-white dark:bg-[#1F1F23] rounded-lg shadow">
        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-8">
          {/* Section Header */}
          <div className="space-y-4">
            <h2 className="text-lg font-semibold">Section Header</h2>
            <div>
              <label className="block text-sm font-medium mb-1">Title</label>
              <input
                {...register("title", { required: true })}
                className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                placeholder="e.g. ANNOUNCEMENTS"
              />
            </div>
          </div>

          {/* Announcements */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Announcements</h2>
              <button
                type="button"
                onClick={handleAddAnnouncement}
                className="px-3 py-1 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
              >
                Add Announcement
              </button>
            </div>
            <div className="space-y-6">
              {fields.map((field, index) => (
                <div key={field.id} className="p-4 border rounded-md dark:border-[#3D3D43] space-y-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="mb-4">
                        <label className="block text-sm font-medium mb-1">Title</label>
                        <input
                          {...register(`announcements.${index}.title`, { required: true })}
                          className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                          placeholder="Enter announcement title"
                        />
                      </div>
                      <div className="mb-4">
                        <label className="block text-sm font-medium mb-1">Description</label>
                        <textarea
                          {...register(`announcements.${index}.description`, { required: true })}
                          className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                          rows={3}
                          placeholder="Enter announcement description"
                        />
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                        <div>
                          <label className="block text-sm font-medium mb-1">Day</label>
                          <input
                            {...register(`announcements.${index}.date.day`, { required: true })}
                            className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                            placeholder="DD"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-1">Month</label>
                          <input
                            {...register(`announcements.${index}.date.month`, { required: true })}
                            className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                            placeholder="MMM"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-1">Year</label>
                          <input
                            {...register(`announcements.${index}.date.year`, { required: true })}
                            className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                            placeholder="YYYY"
                          />
                        </div>
                        <div className="flex items-center">
                          <label className="flex items-center space-x-2">
                            <input
                              type="checkbox"
                              {...register(`announcements.${index}.isNew`)}
                              className="w-4 h-4 border rounded dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                            />
                            <span className="text-sm font-medium">Mark as New</span>
                          </label>
                        </div>
                      </div>
                      <input 
                        type="hidden" 
                        {...register(`announcements.${index}.id`)} 
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => remove(index)}
                      className="ml-4 px-3 py-1 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-md transition-colors"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))}
              {fields.length === 0 && (
                <p className="text-gray-500 dark:text-gray-400 text-center py-4">
                  No announcements added. Click "Add Announcement" to add one.
                </p>
              )}
            </div>
          </div>

          <button
            type="submit"
            disabled={isSaving}
            className={`px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors ${
              isSaving ? "opacity-70 cursor-not-allowed" : ""
            }`}
          >
            {isSaving ? "Saving..." : "Save Changes"}
          </button>
        </form>
      </div>
    </div>
  )
} 