"use client"

import { useState, useEffect } from "react"
import { useForm } from "react-hook-form"
import LoadingSpinner from "@/components/LoadingSpinner"

interface ContactItem {
  id: number
  label: string
  value?: string
  isMain?: boolean
  isAddress?: boolean
  isContact?: boolean
}

interface ServiceItem {
  id: number
  label: string
  href: string
}

interface LinkItem {
  id: number
  label: string
  href: string
}

interface SocialLink {
  id: number
  platform: string
  url: string
  icon: string
  ariaLabel: string
}

interface FooterContent {
  aboutUs: {
    title: string
    description: string
  }
  contactUs: {
    title: string
    items: ContactItem[]
  }
  ourServices: {
    title: string
    items: ServiceItem[]
  }
  usefulLinks: {
    title: string
    items: LinkItem[]
  }
  socialLinks: SocialLink[]
}

export default function FooterPage() {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const { register, handleSubmit, reset } = useForm<FooterContent>()

  useEffect(() => {
    fetchFooterContent()
  }, [])

  async function fetchFooterContent() {
    try {
      const response = await fetch("/api/footer")
      const data = await response.json()
      reset(data)
      setLoading(false)
    } catch (err) {
      setError("Failed to load footer content")
      setLoading(false)
      console.error("Fetch error:", err)
    }
  }

  async function onSubmit(data: FooterContent) {
    try {
      const response = await fetch("/api/footer", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      if (!response.ok) throw new Error("Failed to save footer content")
      alert("Footer content saved successfully!")
    } catch (err) {
      setError("Failed to save footer content")
      console.error("Submit error:", err)
    }
  }

  if (loading) {
    return (
        <LoadingSpinner />
    )
  }
  if (error) return <div className="p-6 text-red-500">{error}</div>

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Manage Footer</h1>

      <div className="bg-white dark:bg-[#1F1F23] rounded-lg shadow">
        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-8">
          {/* About Us Section */}
          <div className="space-y-4">
            <h2 className="text-lg font-semibold">About Us</h2>
            <div>
              <label className="block text-sm font-medium mb-1">Title</label>
              <input
                {...register("aboutUs.title", { required: true })}
                className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Description</label>
              <textarea
                {...register("aboutUs.description", { required: true })}
                className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                rows={4}
              />
            </div>
          </div>

          {/* Contact Us Section */}
          <div className="space-y-4">
            <h2 className="text-lg font-semibold">Contact Us</h2>
            <div>
              <label className="block text-sm font-medium mb-1">Title</label>
              <input
                {...register("contactUs.title", { required: true })}
                className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
              />
            </div>
            <div className="space-y-4">
              {[0, 1, 2, 3, 4].map((index) => (
                <div key={index} className="grid grid-cols-1 md:grid-cols-2 gap-4 border p-4 rounded-md dark:border-[#3D3D43]">
                  <div>
                    <label className="block text-sm font-medium mb-1">Label</label>
                    <input
                      {...register(`contactUs.items.${index}.label` as const)}
                      className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Value (optional)</label>
                    <input
                      {...register(`contactUs.items.${index}.value` as const)}
                      className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Our Services Section */}
          <div className="space-y-4">
            <h2 className="text-lg font-semibold">Our Services</h2>
            <div>
              <label className="block text-sm font-medium mb-1">Title</label>
              <input
                {...register("ourServices.title", { required: true })}
                className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
              />
            </div>
            <div className="space-y-4">
              {[0, 1, 2].map((index) => (
                <div key={index} className="grid grid-cols-1 md:grid-cols-2 gap-4 border p-4 rounded-md dark:border-[#3D3D43]">
                  <div>
                    <label className="block text-sm font-medium mb-1">Label</label>
                    <input
                      {...register(`ourServices.items.${index}.label` as const)}
                      className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Link</label>
                    <input
                      {...register(`ourServices.items.${index}.href` as const)}
                      className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Useful Links Section */}
          <div className="space-y-4">
            <h2 className="text-lg font-semibold">Useful Links</h2>
            <div>
              <label className="block text-sm font-medium mb-1">Title</label>
              <input
                {...register("usefulLinks.title", { required: true })}
                className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
              />
            </div>
            <div className="space-y-4">
              {[0, 1, 2, 3, 4].map((index) => (
                <div key={index} className="grid grid-cols-1 md:grid-cols-2 gap-4 border p-4 rounded-md dark:border-[#3D3D43]">
                  <div>
                    <label className="block text-sm font-medium mb-1">Label</label>
                    <input
                      {...register(`usefulLinks.items.${index}.label` as const)}
                      className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Link</label>
                    <input
                      {...register(`usefulLinks.items.${index}.href` as const)}
                      className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Social Links Section */}
          <div className="space-y-4">
            <h2 className="text-lg font-semibold">Social Links</h2>
            <div className="space-y-4">
              {[0, 1, 2, 3].map((index) => (
                <div key={index} className="grid grid-cols-1 md:grid-cols-2 gap-4 border p-4 rounded-md dark:border-[#3D3D43]">
                  <div>
                    <label className="block text-sm font-medium mb-1">Platform</label>
                    <input
                      {...register(`socialLinks.${index}.platform` as const)}
                      className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">URL</label>
                    <input
                      {...register(`socialLinks.${index}.url` as const)}
                      className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Icon</label>
                    <input
                      {...register(`socialLinks.${index}.icon` as const)}
                      className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Aria Label</label>
                    <input
                      {...register(`socialLinks.${index}.ariaLabel` as const)}
                      className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Save Changes
          </button>
        </form>
      </div>
    </div>
  )
} 