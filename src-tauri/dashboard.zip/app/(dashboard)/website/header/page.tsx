"use client"

import LoadingSpinner from "@/components/LoadingSpinner"
import { useState, useEffect } from "react"
import { useForm, useFieldArray } from "react-hook-form"

interface NavigationLink {
  id: number
  label: string
  href: string
}

interface HeaderContent {
  navigationLinks: NavigationLink[]
}

export default function HeaderPage() {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const { register, handleSubmit, reset, control } = useForm<HeaderContent>({
    defaultValues: {
      navigationLinks: []
    }
  })
  
  const { fields, append, remove } = useFieldArray({
    control,
    name: "navigationLinks"
  })

  useEffect(() => {
    fetchHeaderContent()
  }, [])

  async function fetchHeaderContent() {
    try {
      const response = await fetch("/api/header")
      const data = await response.json()
      reset(data)
      setLoading(false)
    } catch (err) {
      setError("Failed to load header content")
      setLoading(false)
      console.error("Fetch error:", err)
    }
  }

  async function onSubmit(data: HeaderContent) {
    try {
      // Ensure IDs are properly set
      data.navigationLinks = data.navigationLinks.map((link, index) => ({
        ...link,
        id: index + 1
      }))

      const response = await fetch("/api/header", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      if (!response.ok) throw new Error("Failed to save header content")
      alert("Header content saved successfully!")
    } catch (err) {
      setError("Failed to save header content")
      console.error("Submit error:", err)
    }
  }

  function handleAddLink() {
    append({ id: fields.length + 1, label: "", href: "" })
  }

  if (loading) {
    return (
        <LoadingSpinner />
    )
  }
  if (error) return <div className="p-6 text-red-500">{error}</div>

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Manage Header</h1>

      <div className="bg-white dark:bg-[#1F1F23] rounded-lg shadow">
        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
          {/* Navigation Links */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Navigation Links</h2>
              <button
                type="button"
                onClick={handleAddLink}
                className="px-3 py-1 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
              >
                Add Link
              </button>
            </div>
            <div className="space-y-4">
              {fields.map((field, index) => (
                <div key={field.id} className="flex items-start gap-4 p-4 border rounded-md dark:border-[#3D3D43]">
                  <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Label</label>
                      <input
                        {...register(`navigationLinks.${index}.label`)}
                        className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                        placeholder="e.g. Home"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">URL</label>
                      <input
                        {...register(`navigationLinks.${index}.href`)}
                        className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                        placeholder="e.g. / or #about"
                      />
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => remove(index)}
                    className="mt-7 px-3 py-1 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-md transition-colors"
                  >
                    Remove
                  </button>
                </div>
              ))}
              {fields.length === 0 && (
                <p className="text-gray-500 dark:text-gray-400 text-center py-4">
                  No navigation links added. Click "Add Link" to add one.
                </p>
              )}
            </div>
          </div>

          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Save Changes
          </button>
        </form>
      </div>
    </div>
  )
} 