"use client"

import { useState, useEffect } from "react"
import { useForm } from "react-hook-form"
import LoadingSpinner from "@/components/LoadingSpinner"
interface ChatOption {
  id: number
  text: string
  icon: string
}

interface ChatData {
  userMessage: string
  botResponse: string
  userName: string
  options: ChatOption[]
}

interface HeroContent {
  headline: string
  subheadline: string
  ctaText: string
  chatData: ChatData
}

export default function HeroPage() {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const { register, handleSubmit, reset } = useForm<HeroContent>()

  useEffect(() => {
    fetchHeroContent()
  }, [])

  async function fetchHeroContent() {
    try {
      const response = await fetch("/api/hero")
      const data = await response.json()
      reset(data) // Pre-fill form with existing data
      setLoading(false)
    } catch (err) {
      setError("Failed to load hero content")
      setLoading(false)
      console.error("Fetch error:", err)
    }
  }

  async function onSubmit(data: HeroContent) {
    try {
      const response = await fetch("/api/hero", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      if (!response.ok) throw new Error("Failed to save hero content")
      
      // Show success message
      alert("Hero content saved successfully!")
    } catch (err) {
      setError("Failed to save hero content")
      console.error("Submit error:", err)
    }
  }

  if (loading) {return (<LoadingSpinner />)}
  if (error) return <div className="p-6 text-red-500">{error}</div>

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Manage Hero Section</h1>

      <div className="bg-white dark:bg-[#1F1F23] rounded-lg shadow">
        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
          {/* Main Hero Content */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Headline</label>
              <input
                {...register("headline", { required: true })}
                className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Subheadline</label>
              <input
                {...register("subheadline", { required: true })}
                className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">CTA Text</label>
              <input
                {...register("ctaText", { required: true })}
                className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
              />
            </div>
          </div>

          {/* Chat Data Section */}
          <div className="border-t pt-6 dark:border-[#3D3D43]">
            <h2 className="text-lg font-semibold mb-4">Chat Preview Settings (not working)</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">User Message</label>
                <input
                  {...register("chatData.userMessage", { required: true })}
                  className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Bot Response</label>
                <input
                  {...register("chatData.botResponse", { required: true })}
                  className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">User Name</label>
                <input
                  {...register("chatData.userName", { required: true })}
                  className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                />
              </div>

              {/* Chat Options */}
              <div>
                <label className="block text-sm font-medium mb-2">Chat Options</label>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">Option 1</label>
                      <input
                        {...register("chatData.options.0.text")}
                        placeholder="Option text"
                        className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43] mb-2"
                      />
                      <input
                        {...register("chatData.options.0.icon")}
                        placeholder="Icon name"
                        className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">Option 2</label>
                      <input
                        {...register("chatData.options.1.text")}
                        placeholder="Option text"
                        className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43] mb-2"
                      />
                      <input
                        {...register("chatData.options.1.icon")}
                        placeholder="Icon name"
                        className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Save Changes
          </button>
        </form>
      </div>
    </div>
  )
} 