"use client"

import { useState, useEffect } from "react"
import { useForm, useFieldArray } from "react-hook-form"
import LoadingSpinner from "@/components/LoadingSpinner"

interface Step {
  id: number
  title: string
  description: string
  icon: string
}

interface HowItWorksData {
  title: string
  subtitle: string
  steps: Step[]
}

export default function HowItWorksPage() {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const { register, handleSubmit, reset, control } = useForm<HowItWorksData>({
    defaultValues: {
      steps: []
    }
  })

  const { fields, append, remove } = useFieldArray({
    control,
    name: "steps"
  })

  useEffect(() => {
    fetchHowItWorks()
  }, [])

  async function fetchHowItWorks() {
    try {
      const response = await fetch("/api/how")
      const data = await response.json()
      reset(data)
      setLoading(false)
    } catch (err) {
      setError("Failed to load how-it-works data")
      setLoading(false)
      console.error("Fetch error:", err)
    }
  }

  async function onSubmit(data: HowItWorksData) {
    try {
      // Ensure IDs are sequential
      data.steps = data.steps.map((step, index) => ({
        ...step,
        id: index + 1
      }))

      const response = await fetch("/api/how", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      if (!response.ok) throw new Error("Failed to save how-it-works section")
      alert("Changes saved successfully!")
    } catch (err) {
      setError("Failed to save how-it-works section")
      console.error("Submit error:", err)
    }
  }

  function handleAddStep() {
    append({
      id: fields.length + 1,
      title: "",
      description: "",
      icon: "/images/how/" + (fields.length + 1) + ".png"
    })
  }

  if (loading) {
    return (
        <LoadingSpinner />
    )
  }
  if (error) return <div className="p-6 text-red-500">{error}</div>

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Manage How It Works Section</h1>

      <div className="bg-white dark:bg-[#1F1F23] rounded-lg shadow">
        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-8">
          {/* Section Header */}
          <div className="space-y-4">
            <h2 className="text-lg font-semibold">Section Header</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Title</label>
                <input
                  {...register("title", { required: true })}
                  className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                  placeholder="e.g. How it works"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Subtitle</label>
                <input
                  {...register("subtitle", { required: true })}
                  className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                  placeholder="e.g. Start your legal Service in Four Simple Steps."
                />
              </div>
            </div>
          </div>

          {/* Steps */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Steps</h2>
              <button
                type="button"
                onClick={handleAddStep}
                className="px-3 py-1 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
              >
                Add Step
              </button>
            </div>
            <div className="space-y-6">
              {fields.map((field, index) => (
                <div key={field.id} className="p-4 border rounded-md dark:border-[#3D3D43] space-y-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1 space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium mb-1">Title</label>
                          <input
                            {...register(`steps.${index}.title`)}
                            className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                            placeholder="Enter step title"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-1">Icon Path</label>
                          <input
                            {...register(`steps.${index}.icon`)}
                            className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                            placeholder="/images/how/1.png"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">Description</label>
                        <textarea
                          {...register(`steps.${index}.description`)}
                          className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                          rows={3}
                          placeholder="Enter step description"
                        />
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => remove(index)}
                      className="ml-4 px-3 py-1 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-md transition-colors"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))}
              {fields.length === 0 && (
                <p className="text-gray-500 dark:text-gray-400 text-center py-4">
                  No steps added. Click "Add Step" to add one.
                </p>
              )}
            </div>
          </div>

          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Save Changes
          </button>
        </form>
      </div>
    </div>
  )
} 