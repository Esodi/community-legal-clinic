"use client"

import { useState, useEffect } from "react"
import { useForm } from "react-hook-form"
import LoadingSpinner from "@/components/LoadingSpinner"
interface Offering {
  id: number
  text: string
}

interface Service {
  id: number
  title: string
  videoThumbnail: string
  videoUrl: string
  offerings: Offering[]
}

interface ServiceFormData {
  title: string
  videoThumbnail: string
  videoUrl: string
  offering1: string
  offering2: string
  offering3: string
}

export default function ServicesPage() {
  const [services, setServices] = useState<Service[]>([])
  const [loading, setLoading] = useState(true)
  const [deletingId, setDeletingId] = useState<number | null>(null)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const { register, handleSubmit, reset, formState: { errors } } = useForm<ServiceFormData>()

  useEffect(() => {
    fetchServices()
  }, [])

  async function fetchServices() {
    try {
      const response = await fetch("/api/services")
      const data = await response.json()
      setServices(data.packages || [])
      setLoading(false)
    } catch (err) {
      setError("Failed to load services")
      setLoading(false)
      console.error("Fetch error:", err)
    }
  }

  async function onSubmit(formData: ServiceFormData) {
    try {
      setLoading(true)
      setError("")
      setSuccess("")
      // Generate a new ID
      const newId = Math.max(0, ...services.map(s => s.id)) + 1
      
      // Create service object from form data
      const newService: Service = {
        id: newId,
        title: formData.title,
        videoThumbnail: formData.videoThumbnail || "",
        videoUrl: formData.videoUrl || "",
        offerings: [
          { id: 1, text: formData.offering1 },
          { id: 2, text: formData.offering2 },
          { id: 3, text: formData.offering3 }
        ].filter(offering => offering.text.trim() !== "")
      }

      const response = await fetch("/api/services", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newService),
      })

      if (!response.ok) throw new Error("Failed to save service")

      reset() // Reset form
      setSuccess("Service added successfully!")
      await fetchServices() // Refresh list
      setLoading(false)
    } catch (err) {
      setError("Failed to save service")
      setLoading(false)
      console.error("Submit error:", err)
    }
  }

  async function handleDelete(serviceId: number) {
    try {
      setDeletingId(serviceId)
      setError("")
      setSuccess("")
      const newServices = services.filter(s => s.id !== serviceId)
      const response = await fetch("/api/services", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ packages: newServices }),
      })

      if (!response.ok) throw new Error("Failed to delete service")

      setServices(newServices)
      setSuccess("Service deleted successfully!")
      setDeletingId(null)
    } catch (err) {
      setError("Failed to delete service")
      setDeletingId(null)
      console.error("Delete error:", err)
    }
  }

  if (loading) {
    return (
        <LoadingSpinner />
    )
  }
  if (error) return <div className="p-6 text-red-500">{error}</div>

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Manage Services</h1>
      
      {error && <div className="p-4 mb-6 bg-red-100 text-red-700 rounded-md">{error}</div>}
      {success && <div className="p-4 mb-6 bg-green-100 text-green-700 rounded-md">{success}</div>}

      {/* Add Service Form */}
      <div className="mb-8 p-6 bg-white dark:bg-[#1F1F23] rounded-lg shadow">
        <h2 className="text-lg font-semibold mb-4">Add New Service</h2>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Title</label>
            <input
              {...register("title", { required: "Title is required" })}
              className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
            />
            {errors.title && <p className="mt-1 text-sm text-red-500">{errors.title.message}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Video Thumbnail URL</label>
            <input
              {...register("videoThumbnail")}
              className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
              placeholder="/services/1.jpg"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Video URL</label>
            <input
              {...register("videoUrl")}
              className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
              placeholder="https://youtu.be/..."
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Offering 1</label>
            <input
              {...register("offering1", { required: "At least one offering is required" })}
              className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
            />
            {errors.offering1 && <p className="mt-1 text-sm text-red-500">{errors.offering1.message}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Offering 2</label>
            <input
              {...register("offering2", { required: true })}
              className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Offering 3</label>
            <input
              {...register("offering3", { required: true })}
              className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors disabled:opacity-70"
            disabled={loading}
          >
            {loading ? "Adding..." : "Add Service"}
          </button>
        </form>
      </div>

      {/* Services List */}
      <div className="bg-white dark:bg-[#1F1F23] rounded-lg shadow">
        <h2 className="text-lg font-semibold p-6 border-b dark:border-[#3D3D43]">Current Services</h2>
        <div className="divide-y dark:divide-[#3D3D43]">
          {services.map((service) => (
            <div key={service.id} className="p-6 flex items-start justify-between">
              <div className="flex-1">
                <h3 className="font-medium">{service.title}</h3>
                {service.videoThumbnail && (
                  <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
                    Thumbnail: {service.videoThumbnail}
                  </p>
                )}
                {service.videoUrl && (
                  <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
                    Video: {service.videoUrl}
                  </p>
                )}
                <div className="mt-2">
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Offerings:</p>
                  <ul className="list-disc list-inside mt-1">
                    {service.offerings.map((offering) => (
                      <li key={offering.id} className="text-sm text-gray-600 dark:text-gray-400">
                        {offering.text}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              <button
                onClick={() => handleDelete(service.id)}
                className="ml-4 px-3 py-1 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-md transition-colors disabled:opacity-70"
                disabled={deletingId === service.id}
              >
                {deletingId === service.id ? 'Deleting...' : 'Delete'}
              </button>
            </div>
          ))}
          {services.length === 0 && (
            <p className="p-6 text-gray-500 dark:text-gray-400">No services added yet.</p>
          )}
        </div>
      </div>
    </div>
  )
} 