"use client"

import { useState, useEffect } from "react"
import { useForm, useFieldArray } from "react-hook-form"
import LoadingSpinner from "@/components/LoadingSpinner"
interface Testimonial {
  id: number
  name: string
  location: string
  text: string
  image: string
}

interface TestimonialsData {
  title: string
  subtitle: string
  testimonials: Testimonial[]
}

export default function TestimonialsPage() {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const { register, handleSubmit, reset, control } = useForm<TestimonialsData>({
    defaultValues: {
      testimonials: []
    }
  })

  const { fields, append, remove } = useFieldArray({
    control,
    name: "testimonials"
  })

  useEffect(() => {
    fetchTestimonials()
  }, [])

  async function fetchTestimonials() {
    try {
      const response = await fetch("/api/testimonials")
      const data = await response.json()
      reset(data)
      setLoading(false)
    } catch (err) {
      setError("Failed to load testimonials")
      setLoading(false)
      console.error("Fetch error:", err)
    }
  }

  async function onSubmit(data: TestimonialsData) {
    try {
      // Ensure IDs are properly set
      data.testimonials = data.testimonials.map((testimonial, index) => ({
        ...testimonial,
        id: index + 1
      }))

      const response = await fetch("/api/testimonials", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      if (!response.ok) throw new Error("Failed to save testimonials")
      alert("Testimonials saved successfully!")
    } catch (err) {
      setError("Failed to save testimonials")
      console.error("Submit error:", err)
    }
  }

  function handleAddTestimonial() {
    append({
      id: fields.length + 1,
      name: "",
      location: "",
      text: "",
      image: "/testimonials/default.jpg"
    })
  }

  if (loading) {
    return (
        <LoadingSpinner />
    )
  }
  if (error) return <div className="p-6 text-red-500">{error}</div>

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Manage Testimonials</h1>

      <div className="bg-white dark:bg-[#1F1F23] rounded-lg shadow">
        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-8">
          {/* Section Header */}
          <div className="space-y-4">
            <h2 className="text-lg font-semibold">Section Header</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Title</label>
                <input
                  {...register("title", { required: true })}
                  className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                  placeholder="e.g. Trusted by 4000+ Clients since 2021"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Subtitle</label>
                <textarea
                  {...register("subtitle", { required: true })}
                  className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                  rows={2}
                  placeholder="Enter a brief description of your testimonials section"
                />
              </div>
            </div>
          </div>

          {/* Testimonials */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Testimonials</h2>
              <button
                type="button"
                onClick={handleAddTestimonial}
                className="px-3 py-1 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
              >
                Add Testimonial
              </button>
            </div>
            <div className="space-y-6">
              {fields.map((field, index) => (
                <div key={field.id} className="p-4 border rounded-md dark:border-[#3D3D43] space-y-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Name</label>
                        <input
                          {...register(`testimonials.${index}.name`)}
                          className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                          placeholder="e.g. Advocate Raheli L."
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">Location</label>
                        <input
                          {...register(`testimonials.${index}.location`)}
                          className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                          placeholder="e.g. Arusha"
                        />
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => remove(index)}
                      className="ml-4 px-3 py-1 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-md transition-colors"
                    >
                      Remove
                    </button>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Testimonial Text</label>
                    <textarea
                      {...register(`testimonials.${index}.text`)}
                      className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                      rows={4}
                      placeholder="Enter the client's testimonial"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Image URL</label>
                    <input
                      {...register(`testimonials.${index}.image`)}
                      className="w-full px-3 py-2 border rounded-md dark:bg-[#2D2D33] dark:border-[#3D3D43]"
                      placeholder="/testimonials/client1.jpg"
                    />
                  </div>
                </div>
              ))}
              {fields.length === 0 && (
                <p className="text-gray-500 dark:text-gray-400 text-center py-4">
                  No testimonials added. Click "Add Testimonial" to add one.
                </p>
              )}
            </div>
          </div>

          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Save Changes
          </button>
        </form>
      </div>
    </div>
  )
} 