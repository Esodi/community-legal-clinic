"use client"

import { useState, useEffect } from "react"
import LoadingSpinner from "@/components/LoadingSpinner"

interface User {
  id: string
  username: string
  email: string
  role: string
  createdAt: string
}

export default function UsersPage() {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [users, setUsers] = useState<User[]>([])

  useEffect(() => {
    fetchUsers()
  }, [])

  async function fetchUsers() {
    try {
      const response = await fetch("/api/users")
      if (!response.ok) {
        throw new Error("Failed to fetch users")
      }
      const data = await response.json()
      setUsers(data || [])
      setLoading(false)
    } catch (err) {
      setError("Failed to load users")
      setLoading(false)
      console.error("Fetch error:", err)
    }
  }

  if (loading) {
    return (
        <LoadingSpinner />
    )
  }
  if (error) return <div className="p-6 text-red-500">{error}</div>

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Users List</h1>
      </div>

      <div className="bg-white dark:bg-[#1F1F23] rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 dark:bg-[#2D2D33] text-left">
                <th className="p-4 font-semibold text-gray-900 dark:text-white">Username</th>
                <th className="p-4 font-semibold text-gray-900 dark:text-white">Email</th>
                <th className="p-4 font-semibold text-gray-900 dark:text-white">Role</th>
                <th className="p-4 font-semibold text-gray-900 dark:text-white">Created At</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id} className="border-t dark:border-[#3D3D43] hover:bg-gray-50 dark:hover:bg-[#2D2D33] transition-colors">
                  <td className="p-4 text-gray-900 dark:text-gray-200">
                    {user.username}
                  </td>
                  <td className="p-4 text-gray-900 dark:text-gray-200">
                    {user.email}
                  </td>
                  <td className="p-4">
                    <span className="px-2 py-1 text-sm rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                      {user.role}
                    </span>
                  </td>
                  <td className="p-4 text-sm text-gray-600 dark:text-gray-400">
                    {new Date(user.createdAt).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
} 