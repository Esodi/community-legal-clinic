import { promises as fs } from 'fs'
import { NextResponse } from 'next/server'
import path from 'path'

export const dynamic = 'force-dynamic'
export const revalidate = 0

const dataFilePath = path.join(process.cwd(), 'app/api/announcements.json')

// Simple interfaces without complex validation
interface Date {
  day: string
  month: string
  year: string
}

interface Announcement {
  id: number
  title: string
  description: string
  date: Date
  isNew: boolean | string
}

interface AnnouncementsData {
  title: string
  announcements: Announcement[]
}

// Simple function to ensure boolean values
function normalizeAnnouncement(announcement: Announcement): Announcement {
  return {
    ...announcement,
    isNew: typeof announcement.isNew === 'string' 
      ? announcement.isNew.toLowerCase() === 'true'
      : !!announcement.isNew
  }
}

export async function GET() {
  try {
    const jsonData = await fs.readFile(dataFilePath, 'utf-8')
    const data = JSON.parse(jsonData)
    
    // Normalize booleans if needed and return
    const normalizedData = {
      ...data,
      announcements: data.announcements.map(normalizeAnnouncement)
    }
    
    return NextResponse.json(normalizedData)
  } catch (error) {
    console.error('Error reading announcements:', error)
    return new NextResponse('Internal Server Error', { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const newAnnouncement = await request.json()
    const fileContent = await fs.readFile(dataFilePath, 'utf8')
    const data = JSON.parse(fileContent)
    
    // Generate new ID
    const maxId = Math.max(0, ...data.announcements.map((a: any) => a.id))
    const announcementWithId = {
      ...newAnnouncement,
      id: maxId + 1,
      isNew: typeof newAnnouncement.isNew === 'string'
        ? newAnnouncement.isNew.toLowerCase() === 'true'
        : !!newAnnouncement.isNew
    }
    
    // Add to array
    data.announcements.push(announcementWithId)
    
    await fs.writeFile(dataFilePath, JSON.stringify(data, null, 2))
    return NextResponse.json(data)
  } catch (error) {
    console.error('Error adding announcement:', error)
    return new NextResponse('Internal Server Error', { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const updatedAnnouncement = await request.json()
    const fileContent = await fs.readFile(dataFilePath, 'utf8')
    const data = JSON.parse(fileContent)
    
    // Find and update the announcement
    if (Array.isArray(updatedAnnouncement)) {
      // Handle array of announcements (full update)
      data.announcements = updatedAnnouncement.map(normalizeAnnouncement)
    } else if (updatedAnnouncement.announcements) {
      // Handle complete data structure
      data.title = updatedAnnouncement.title || data.title
      data.announcements = updatedAnnouncement.announcements.map(normalizeAnnouncement)
    } else {
      // Handle single announcement update
      const index = data.announcements.findIndex((a: any) => a.id === updatedAnnouncement.id)
      if (index !== -1) {
        data.announcements[index] = normalizeAnnouncement(updatedAnnouncement)
      } else {
        return new NextResponse('Announcement not found', { status: 404 })
      }
    }
    
    await fs.writeFile(dataFilePath, JSON.stringify(data, null, 2))
    return NextResponse.json({ message: 'Announcements updated successfully' })
  } catch (error) {
    console.error('Error updating announcements:', error)
    return new NextResponse('Internal Server Error', { status: 500 })
  }
} 