import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { promises as fs } from 'fs'
import path from 'path'

const dataFilePath = path.join(process.cwd(), 'app/api/auth.json')

async function getSession(token: string) {
  try {
    // Read auth data file
    let authData;
    try {
      const data = await fs.readFile(dataFilePath, 'utf-8')
      authData = JSON.parse(data)
      
      if (!authData.sessions || !Array.isArray(authData.sessions)) {
        console.error('Invalid auth.json format:', authData)
        return null
      }
    } catch (error) {
      console.error('Error reading auth file:', error)
      return null
    }
    
    // Find session
    const session = authData.sessions.find((s: any) => s.token === token)

    if (session) {
      // Update last active time
      session.lastActive = new Date().toISOString()
      await fs.writeFile(dataFilePath, JSON.stringify(authData, null, 2))
    }

    return session
  } catch (error) {
    console.error('Error getting session:', error)
    return null
  }
}

export async function GET() {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get('token')?.value
    const username = cookieStore.get('username')?.value
    
    // Log all cookies to help with debugging
    const allCookies = cookieStore.getAll().map((cookie) => cookie.name)
    //console.log('Auth check cookies:', { allCookies, hasToken: !!token, hasUsername: !!username })

    if (!token || !username) {
      return NextResponse.json({ 
        isAuthenticated: false, 
        reason: 'missing_cookies',
        details: { hasToken: !!token, hasUsername: !!username }
      }, { status: 401 })
    }

    const session = await getSession(token)
    if (!session) {
      return NextResponse.json({ 
        isAuthenticated: false, 
        reason: 'invalid_session',
        details: { token: token.slice(0, 5) + '...' } 
      }, { status: 401 })
    }
    
    if (session.username !== username) {
      return NextResponse.json({ 
        isAuthenticated: false, 
        reason: 'username_mismatch',
        details: { sessionUser: session.username, cookieUser: username }
      }, { status: 401 })
    }

    // Check session expiration
    const lastActive = new Date(session.lastActive)
    const now = new Date()
    const hoursSinceActive = (now.getTime() - lastActive.getTime()) / (1000 * 60 * 60)
    
    if (hoursSinceActive >= 24) {
      return NextResponse.json({ 
        isAuthenticated: false, 
        reason: 'session_expired',
        details: { hoursSinceActive }
      }, { status: 401 })
    }

    return NextResponse.json({
      isAuthenticated: true,
      user: {
        username: session.username,
        role: session.role
      }
    })
  } catch (error) {
    console.error('Auth check error:', error)
    return NextResponse.json({ 
      isAuthenticated: false, 
      reason: 'server_error',
      details: error instanceof Error ? error.message : String(error)
    }, { status: 500 })
  }
} 