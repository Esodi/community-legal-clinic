import { NextResponse } from 'next/server';
import { promises as fs } from 'fs';
import path from 'path';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';

const usersFilePath = path.join(process.cwd(), 'app/api/users.json');
const authFilePath = path.join(process.cwd(), 'app/api/auth.json');

interface User {
  id: string;
  username: string;
  password: string;
  role: 'admin' | 'user';
  email: string;
}

async function findUser(username: string): Promise<User | null> {
  try {
    const data = await fs.readFile(usersFilePath, 'utf-8');
    const parsed = JSON.parse(data);
    
    if (!parsed.users || !Array.isArray(parsed.users)) {
      console.error('Invalid users.json format:', parsed);
      return null;
    }
    
    const user = parsed.users.find((u: User) => u.username === username);
    return user || null;
  } catch (error) {
    console.error('Error finding user:', error);
    return null;
  }
}

async function addSession(username: string, role: string) {
  try {
    const token = crypto.randomBytes(32).toString('hex');
    const session = {
      username,
      token,
      role,
      lastActive: new Date().toISOString()
    };

    let authData;
    try {
      const data = await fs.readFile(authFilePath, 'utf-8');
      authData = JSON.parse(data);
      
      if (!authData.sessions) {
        authData.sessions = [];
      }
    } catch (error) {
      // If the file doesn't exist or is invalid, create a new auth data object
      authData = { sessions: [] };
    }
    
    // Remove any existing session for this user
    authData.sessions = authData.sessions.filter((s: any) => s.username !== username);
    
    // Add new session
    authData.sessions.push(session);
    await fs.writeFile(authFilePath, JSON.stringify(authData, null, 2));

    return token;
  } catch (error) {
    console.error('Error adding session:', error);
    return null;
  }
}

export async function POST(request: Request) {
  try {
    const { username, password } = await request.json();

    if (!username || !password) {
      return NextResponse.json(
        { error: 'Username and password are required' },
        { status: 400 }
      );
    }

    // Find user first
    const user = await findUser(username);
    
    if (!user) {
      return NextResponse.json(
        { error: 'Invalid credentials' },
        { status: 401 }
      );
    }
    
    // Then verify password
    let isValidPassword = false;
    try {
      isValidPassword = await bcrypt.compare(password, user.password);
    } catch (error) {
      console.error('Password verification error:', error);
      return NextResponse.json(
        { error: 'Authentication error' },
        { status: 500 }
      );
    }
    
    if (!isValidPassword) {
      return NextResponse.json(
        { error: 'Invalid credentials' },
        { status: 401 }
      );
    }

    const token = await addSession(user.username, user.role);
    if (!token) {
      return NextResponse.json(
        { error: 'Failed to create session' },
        { status: 500 }
      );
    }

    const response = NextResponse.json({
      success: true,
      user: {
        username: user.username,
        role: user.role
      }
    });

    // Set cookies
    response.cookies.set('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 60 * 60 * 24 // 24 hours
    });

    response.cookies.set('username', user.username, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 60 * 60 * 24 // 24 hours
    });
    
    // Set a non-httpOnly cookie for client access
    response.cookies.set('isAuthenticated', 'true', {
      httpOnly: false,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 60 * 60 * 24 // 24 hours
    });

    return response;
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    );
  }
} 