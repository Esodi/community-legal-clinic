import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { promises as fs } from "fs"
import path from "path"

const dataFilePath = path.join(process.cwd(), "app/api/auth.json")

async function removeSession(username?: string, token?: string) {
  try {
    // Read auth data file
    let authData;
    try {
      const data = await fs.readFile(dataFilePath, "utf-8")
      authData = JSON.parse(data)
      
      if (!authData.sessions) {
        console.log('No sessions array found in auth.json')
        return
      }
    } catch (error) {
      console.error('Error reading auth file:', error)
      return
    }

    if (username && token) {
      authData.sessions = authData.sessions.filter(
        (s: any) => s.username !== username && s.token !== token
      )
    } else if (username) {
      authData.sessions = authData.sessions.filter(
        (s: any) => s.username !== username
      )
    } else if (token) {
      authData.sessions = authData.sessions.filter(
        (s: any) => s.token !== token
      )
    }

    await fs.writeFile(dataFilePath, JSON.stringify(authData, null, 2))
  } catch (error) {
    console.error("Error removing session:", error)
  }
}

export async function POST() {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get('token')?.value
    const username = cookieStore.get('username')?.value

    if (token || username) {
      await removeSession(username, token)
    }

    const response = new NextResponse("Logged out successfully")

    // Clear cookies
    response.cookies.set("token", "", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 0
    })

    response.cookies.set("username", "", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 0
    })
    
    // Clear the non-httpOnly cookie
    response.cookies.set("isAuthenticated", "", {
      httpOnly: false,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 0
    })

    return response
  } catch (error) {
    console.error("Logout error:", error)
    return new NextResponse("Internal Server Error", { status: 500 })
  }
} 