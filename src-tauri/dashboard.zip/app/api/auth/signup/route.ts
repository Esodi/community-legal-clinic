import { NextResponse } from "next/server"
import fs from "fs/promises"
import path from "path"
import bcrypt from "bcryptjs"

export async function POST(request: Request) {
  try {
    const { username, email, password } = await request.json()

    // Validate input
    if (!username || !email || !password) {
      return NextResponse.json(
        { error: "All fields are required" },
        { status: 400 }
      )
    }

    if (password.length < 6) {
      return NextResponse.json(
        { error: "Password must be at least 6 characters long" },
        { status: 400 }
      )
    }

    // Read existing users
    const usersPath = path.join(process.cwd(), "app/api/users.json")
    const usersData = await fs.readFile(usersPath, "utf-8")
    const users = JSON.parse(usersData)

    // Check if username or email already exists
    if (users.some((u: any) => u.username === username)) {
      return NextResponse.json(
        { error: "Username already exists" },
        { status: 400 }
      )
    }

    if (users.some((u: any) => u.email === email)) {
      return NextResponse.json(
        { error: "Email already exists" },
        { status: 400 }
      )
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10)

    // Create new user
    const newUser = {
      id: users.length + 1,
      username,
      email,
      password: hashedPassword,
      role: "user",
      createdAt: new Date().toISOString()
    }

    // Add to users array and save
    users.push(newUser)
    await fs.writeFile(usersPath, JSON.stringify(users, null, 2))

    // Return success without password
    const { password: _, ...userWithoutPassword } = newUser
    return NextResponse.json(userWithoutPassword, { status: 201 })
  } catch (error) {
    console.error("Signup error:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
} 