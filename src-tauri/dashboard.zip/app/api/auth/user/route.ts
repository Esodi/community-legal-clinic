import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import path from 'path'
import { promises as fs } from 'fs'

const usersFilePath = path.join(process.cwd(), 'app/api/users.json')

export const dynamic = 'force-dynamic'
export const revalidate = 0

export async function GET() {
  try {
    const cookieStore = await cookies()
    const username = cookieStore.get('username')?.value

    if (!username) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 })
    }

    // Read users file
    try {
      const data = await fs.readFile(usersFilePath, 'utf-8')
      const usersData = JSON.parse(data)
      
      // Find user in users.json
      const user = usersData.users.find((u: any) => u.username === username)
      
      if (!user) {
        console.error(`User ${username} not found in users.json`)
        // Return basic user data based on cookie if user not found
        return NextResponse.json({
          username: username,
          role: 'user'
        })
      }

      // Return user data without sensitive information
      return NextResponse.json({
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role
      })
    } catch (fileError) {
      console.error('Error reading users file:', fileError)
      // Return basic user data if file read fails
      return NextResponse.json({
        username: username,
        role: 'user'
      })
    }
  } catch (error) {
    console.error('Error fetching user data:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
} 