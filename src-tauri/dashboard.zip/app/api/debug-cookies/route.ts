import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

export async function GET() {
  const cookieStore = cookies();
  const allCookies = cookieStore.getAll();
  
  // Get auth-related cookies
  const token = cookieStore.get('token')?.value;
  const username = cookieStore.get('username')?.value;
  
  return NextResponse.json({
    message: 'Cookie debug information',
    authStatus: {
      hasToken: !!token,
      hasUsername: !!username,
      tokenValue: token ? token.slice(0, 10) + '...' : null, // Show partial token for security
    },
    allCookies: allCookies.map(c => ({
      name: c.name,
      // Don't expose full values for security
      hasValue: !!c.value,
      valuePreview: c.value ? `${c.value.slice(0, 5)}...` : null
    })),
  });
} 