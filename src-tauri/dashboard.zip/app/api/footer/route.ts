import { promises as fs } from 'fs'
import { NextResponse } from 'next/server'
import path from 'path'

export const dynamic = 'force-dynamic'
export const revalidate = 0

const dataFilePath = path.join(process.cwd(), 'app/api/footer.json')

// Helper function to validate footer data structure
function isValidFooterData(data: any): boolean {
  return (
    data &&
    // About Us section
    data.aboutUs &&
    typeof data.aboutUs.title === 'string' &&
    typeof data.aboutUs.description === 'string' &&
    
    // Contact Us section
    data.contactUs &&
    typeof data.contactUs.title === 'string' &&
    Array.isArray(data.contactUs.items) &&
    data.contactUs.items.every((item: any) =>
      typeof item.id === 'number' &&
      typeof item.label === 'string' &&
      (item.value === undefined || typeof item.value === 'string')
    ) &&
    
    // Our Services section
    data.ourServices &&
    typeof data.ourServices.title === 'string' &&
    Array.isArray(data.ourServices.items) &&
    data.ourServices.items.every((item: any) =>
      typeof item.id === 'number' &&
      typeof item.label === 'string' &&
      typeof item.href === 'string'
    ) &&
    
    // Useful Links section
    data.usefulLinks &&
    typeof data.usefulLinks.title === 'string' &&
    Array.isArray(data.usefulLinks.items) &&
    data.usefulLinks.items.every((item: any) =>
      typeof item.id === 'number' &&
      typeof item.label === 'string' &&
      typeof item.href === 'string'
    ) &&
    
    // Social Links section
    Array.isArray(data.socialLinks) &&
    data.socialLinks.every((link: any) =>
      typeof link.id === 'number' &&
      typeof link.platform === 'string' &&
      typeof link.url === 'string' &&
      typeof link.icon === 'string' &&
      typeof link.ariaLabel === 'string'
    )
  )
}

export async function GET() {
  try {
    const fileContent = await fs.readFile(dataFilePath, 'utf8')
    const data = JSON.parse(fileContent)
    
    if (!isValidFooterData(data)) {
      throw new Error('Invalid footer data structure')
    }
    
    return NextResponse.json(data)
  } catch (error) {
    console.error('GET error:', error)
    return NextResponse.json(
      { error: 'Failed to read footer data' },
      { status: 500 }
    )
  }
}

export async function PUT(request: Request) {
  try {
    const updatedData = await request.json()
    
    if (!isValidFooterData(updatedData)) {
      return NextResponse.json(
        { error: 'Invalid footer data structure' },
        { status: 400 }
      )
    }
    
    await fs.writeFile(dataFilePath, JSON.stringify(updatedData, null, 2))
    return NextResponse.json(updatedData)
  } catch (error) {
    console.error('PUT error:', error)
    return NextResponse.json(
      { error: 'Failed to update footer' },
      { status: 500 }
    )
  }
} 