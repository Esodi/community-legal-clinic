import { promises as fs } from 'fs'
import { NextResponse } from 'next/server'
import path from 'path'

export const dynamic = 'force-dynamic'
export const revalidate = 0

const dataFilePath = path.join(process.cwd(), 'app/api/header.json')

// Helper function to validate header data structure
function isValidHeaderData(data: any): boolean {
  return (
    data &&
    Array.isArray(data.navigationLinks) &&
    data.navigationLinks.every((link: any) =>
      typeof link.id === 'number' &&
      typeof link.label === 'string' &&
      typeof link.href === 'string'
    )
  )
}

export async function GET() {
  try {
    const jsonData = await fs.readFile(dataFilePath, 'utf-8')
    const data = JSON.parse(jsonData)
    return NextResponse.json(data)
  } catch (error) {
    console.error('Error reading header data:', error)
    return new NextResponse('Internal Server Error', { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const updatedData = await request.json()
    
    if (!isValidHeaderData(updatedData)) {
      return NextResponse.json(
        { error: 'Invalid header data structure' },
        { status: 400 }
      )
    }
    
    await fs.writeFile(dataFilePath, JSON.stringify(updatedData, null, 2))
    return NextResponse.json(updatedData)
  } catch (error) {
    console.error('PUT error:', error)
    return NextResponse.json(
      { error: 'Failed to update header' },
      { status: 500 }
    )
  }
} 