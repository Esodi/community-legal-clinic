import { promises as fs } from 'fs'
import { NextResponse } from 'next/server'
import path from 'path'

export const dynamic = 'force-dynamic'
export const revalidate = 0

const dataFilePath = path.join(process.cwd(), 'app/api/hero.json')

// Helper function to validate hero data structure
function isValidHeroData(data: any): boolean {
  return (
    data &&
    typeof data.headline === 'string' &&
    typeof data.subheadline === 'string' &&
    typeof data.ctaText === 'string' &&
    data.chatData &&
    typeof data.chatData.userMessage === 'string' &&
    typeof data.chatData.botResponse === 'string' &&
    typeof data.chatData.userName === 'string' &&
    Array.isArray(data.chatData.options) &&
    data.chatData.options.length === 2 &&
    data.chatData.options.every((opt: any) =>
      typeof opt.id === 'number' &&
      typeof opt.text === 'string' &&
      typeof opt.icon === 'string'
    )
  )
}

export async function GET() {
  try {
    const fileContent = await fs.readFile(dataFilePath, 'utf8')
    const data = JSON.parse(fileContent)
    
    if (!isValidHeroData(data)) {
      throw new Error('Invalid hero data structure')
    }
    
    return NextResponse.json(data)
  } catch (error) {
    console.error('GET error:', error)
    return NextResponse.json(
      { error: 'Failed to read hero data' },
      { status: 500 }
    )
  }
}

export async function PUT(request: Request) {
  try {
    const updatedData = await request.json()
    
    if (!isValidHeroData(updatedData)) {
      return NextResponse.json(
        { error: 'Invalid hero data structure' },
        { status: 400 }
      )
    }
    
    await fs.writeFile(dataFilePath, JSON.stringify(updatedData, null, 2))
    return NextResponse.json(updatedData)
  } catch (error) {
    console.error('PUT error:', error)
    return NextResponse.json(
      { error: 'Failed to update hero' },
      { status: 500 }
    )
  }
}
 