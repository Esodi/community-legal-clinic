import { promises as fs } from 'fs'
import { NextResponse } from 'next/server'
import path from 'path'

export const dynamic = 'force-dynamic'
export const revalidate = 0

const dataFilePath = path.join(process.cwd(), 'app/api/how.json')

interface Step {
  id: number
  title: string
  description: string
  icon: string
}

interface HowItWorksData {
  title: string
  subtitle: string
  steps: Step[]
}

function isValidStep(step: any): step is Step {
  return (
    typeof step === 'object' &&
    typeof step.id === 'number' &&
    typeof step.title === 'string' &&
    typeof step.description === 'string' &&
    typeof step.icon === 'string'
  )
}

function isValidHowItWorksData(data: any): data is HowItWorksData {
  return (
    typeof data === 'object' &&
    typeof data.title === 'string' &&
    typeof data.subtitle === 'string' &&
    Array.isArray(data.steps) &&
    data.steps.every(isValidStep)
  )
}

export async function GET() {
  try {
    const jsonData = await fs.readFile(dataFilePath, 'utf-8')
    const data = JSON.parse(jsonData)

    if (!isValidHowItWorksData(data)) {
      console.error('Invalid how-it-works data structure in file')
      return new NextResponse('Internal Server Error', { status: 500 })
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error('Error reading how-it-works data:', error)
    return new NextResponse('Internal Server Error', { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const data = await request.json()

    if (!isValidHowItWorksData(data)) {
      console.error('Invalid how-it-works data in request:', data)
      return new NextResponse('Invalid how-it-works data', { status: 400 })
    }

    // Ensure IDs are sequential
    data.steps = data.steps.map((step, index) => ({
      ...step,
      id: index + 1
    }))

    await fs.writeFile(dataFilePath, JSON.stringify(data, null, 2))
    return NextResponse.json({ message: 'How it works section updated successfully' })
  } catch (error) {
    console.error('Error updating how-it-works section:', error)
    return new NextResponse('Internal Server Error', { status: 500 })
  }
} 