import { promises as fs } from 'fs'
import { NextResponse } from 'next/server'
import path from 'path'

export const dynamic = 'force-dynamic'
export const revalidate = 0

const dataFilePath = path.join(process.cwd(), 'app/api/services.json')

// Simple interfaces without complex validation
interface Offering {
  id: number
  text: string
}

interface Service {
  id: number
  title: string
  videoThumbnail: string
  videoUrl: string
  offerings: Offering[]
}

interface ServicesData {
  title: string
  packages: Service[]
}

export async function GET() {
  try {
    const jsonData = await fs.readFile(dataFilePath, 'utf-8')
    const data = JSON.parse(jsonData)
    
    return NextResponse.json(data)
  } catch (error) {
    console.error('Error reading services:', error)
    return new NextResponse('Internal Server Error', { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const newService = await request.json()
    const fileContent = await fs.readFile(dataFilePath, 'utf8')
    const data = JSON.parse(fileContent)
    
    // We already have the ID from the client, no need to generate a new one
    // Just ensure it doesn't conflict with existing IDs
    if (!newService.id) {
      const maxId = Math.max(0, ...data.packages.map((s: any) => s.id))
      newService.id = maxId + 1
    }
    
    // Add to array
    data.packages.push(newService)
    
    await fs.writeFile(dataFilePath, JSON.stringify(data, null, 2))
    return NextResponse.json(data)
  } catch (error) {
    console.error('Error adding service:', error)
    return new NextResponse('Internal Server Error', { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const updatedService = await request.json()
    const fileContent = await fs.readFile(dataFilePath, 'utf8')
    const data = JSON.parse(fileContent)
    
    // Handle different update scenarios
    if (Array.isArray(updatedService)) {
      // Handle array of services (full update)
      data.packages = updatedService
    } else if (updatedService.packages) {
      // Handle complete data structure
      data.title = updatedService.title || data.title
      data.packages = updatedService.packages
    } else {
      // Handle single service update
      const index = data.packages.findIndex((s: any) => s.id === updatedService.id)
      if (index !== -1) {
        data.packages[index] = updatedService
      } else {
        return new NextResponse('Service not found', { status: 404 })
      }
    }
    
    await fs.writeFile(dataFilePath, JSON.stringify(data, null, 2))
    return NextResponse.json({ message: 'Services updated successfully' })
  } catch (error) {
    console.error('Error updating services:', error)
    return new NextResponse('Internal Server Error', { status: 500 })
  }
} 