import { NextResponse } from 'next/server';
import { promises as fs } from 'fs';
import path from 'path';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function GET() {
  try {
    // Check if we can read the users file
    const usersFilePath = path.join(process.cwd(), 'app/api/users.json');
    const userFileExists = await fs.stat(usersFilePath).then(() => true).catch(() => false);
    
    // Check if we can read the auth file
    const authFilePath = path.join(process.cwd(), 'app/api/auth.json');
    const authFileExists = await fs.stat(authFilePath).then(() => true).catch(() => false);
    
    // Return a simple test response
    return NextResponse.json({
      message: 'API test endpoint is working',
      timestamp: new Date().toISOString(),
      files: {
        usersFile: userFileExists,
        authFile: authFileExists
      }
    });
  } catch (error) {
    console.error('Test API error:', error);
    return NextResponse.json({ error: 'Test failed' }, { status: 500 });
  }
} 