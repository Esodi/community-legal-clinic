import { promises as fs } from 'fs'
import { NextResponse } from 'next/server'
import path from 'path'

export const dynamic = 'force-dynamic'
export const revalidate = 0

const dataFilePath = path.join(process.cwd(), 'app/api/testimonials.json')

interface Testimonial {
  id: number
  name: string
  location: string
  text: string
  image: string
}

interface TestimonialsData {
  title: string
  subtitle: string
  testimonials: Testimonial[]
}

function isValidTestimonial(testimonial: any): testimonial is Testimonial {
  return (
    typeof testimonial === 'object' &&
    typeof testimonial.id === 'number' &&
    typeof testimonial.name === 'string' &&
    typeof testimonial.location === 'string' &&
    typeof testimonial.text === 'string' &&
    typeof testimonial.image === 'string'
  )
}

function isValidTestimonialsData(data: any): data is TestimonialsData {
  return (
    typeof data === 'object' &&
    typeof data.title === 'string' &&
    typeof data.subtitle === 'string' &&
    Array.isArray(data.testimonials) &&
    data.testimonials.every(isValidTestimonial)
  )
}

export async function GET() {
  try {
    const jsonData = await fs.readFile(dataFilePath, 'utf-8')
    const data = JSON.parse(jsonData)

    if (!isValidTestimonialsData(data)) {
      console.error('Invalid testimonials data structure in file')
      return new NextResponse('Internal Server Error', { status: 500 })
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error('Error reading testimonials:', error)
    return new NextResponse('Internal Server Error', { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const newTestimonial = await request.json()
    const fileContent = await fs.readFile(dataFilePath, 'utf8')
    const data = JSON.parse(fileContent)
    
    // Validate the new testimonial
    if (
      !newTestimonial ||
      typeof newTestimonial.name !== 'string' ||
      typeof newTestimonial.location !== 'string' ||
      typeof newTestimonial.text !== 'string' ||
      typeof newTestimonial.image !== 'string'
    ) {
      return NextResponse.json(
        { error: 'Invalid testimonial data' },
        { status: 400 }
      )
    }
    
    // Add ID to new testimonial
    newTestimonial.id = Math.max(0, ...data.testimonials.map((t: any) => t.id)) + 1
    
    data.testimonials = [...data.testimonials, newTestimonial]
    
    await fs.writeFile(dataFilePath, JSON.stringify(data, null, 2))
    return NextResponse.json(data)
  } catch (error) {
    console.error('POST error:', error)
    return NextResponse.json(
      { error: 'Failed to add testimonial' },
      { status: 500 }
    )
  }
}

export async function PUT(request: Request) {
  try {
    const data = await request.json()

    if (!isValidTestimonialsData(data)) {
      console.error('Invalid testimonials data in request:', data)
      return new NextResponse('Invalid testimonials data', { status: 400 })
    }

    // Ensure IDs are sequential
    data.testimonials = data.testimonials.map((testimonial, index) => ({
      ...testimonial,
      id: index + 1
    }))

    await fs.writeFile(dataFilePath, JSON.stringify(data, null, 2))
    return NextResponse.json({ message: 'Testimonials updated successfully' })
  } catch (error) {
    console.error('Error updating testimonials:', error)
    return new NextResponse('Internal Server Error', { status: 500 })
  }
} 