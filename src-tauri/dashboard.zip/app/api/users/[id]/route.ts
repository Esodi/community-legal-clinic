import { promises as fs } from 'fs'
import { NextResponse } from 'next/server'
import path from 'path'
import bcrypt from 'bcryptjs'

const dataFilePath = path.join(process.cwd(), 'app/api/users.json')

interface User {
  id: string
  username: string
  email: string
  password?: string
  role: string
  createdAt: string
}

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const fileContent = await fs.readFile(dataFilePath, 'utf8')
    const data = JSON.parse(fileContent)
    
    const user = data.users.find((u: User) => u.id === params.id)
    
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Don't send password back
    const { password, ...userWithoutPassword } = user
    return NextResponse.json(userWithoutPassword)
  } catch (error) {
    console.error('Error fetching user:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const updates = await request.json()
    const fileContent = await fs.readFile(dataFilePath, 'utf8')
    const data = JSON.parse(fileContent)
    
    const userIndex = data.users.findIndex((u: User) => u.id === params.id)
    
    if (userIndex === -1) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Validate updates
    if (!updates.username || !updates.email) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Check for duplicate email (excluding current user)
    const emailExists = data.users.some(
      (u: User) => u.email === updates.email && u.id !== params.id
    )
    if (emailExists) {
      return NextResponse.json({ error: 'Email already exists' }, { status: 400 })
    }

    // Check for duplicate username (excluding current user)
    const usernameExists = data.users.some(
      (u: User) => u.username === updates.username && u.id !== params.id
    )
    if (usernameExists) {
      return NextResponse.json({ error: 'Username already exists' }, { status: 400 })
    }

    // Update user while preserving other fields
    const updatedUser = {
      ...data.users[userIndex],
      username: updates.username,
      email: updates.email,
    }
    
    data.users[userIndex] = updatedUser
    await fs.writeFile(dataFilePath, JSON.stringify(data, null, 2))

    // Don't send password back
    const { password, ...userWithoutPassword } = updatedUser
    return NextResponse.json(userWithoutPassword)
  } catch (error) {
    console.error('Error updating user:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
} 