import Hero from '@/components/Hero';
import Services from '@/components/Services';
import How from '@/components/How';
import Announcements from '@/components/Announcements';
import Footer from '@/components/Footer';
import Testimonials from '@/components/Testimonials';
import GradientBackground from '@/components/GradientBackground';
import { getHeroData, getServicesData, getHowData, getAnnouncementsData, getFooterData, getTestimonialsData, getHeaderData } from '@/lib/api';
import Header from '@/components/Header';

//export const dynamic = 'force-dynamic';

export default async function Home() {
  const [heroData, servicesData, howData, announcementsData, footerData, testimonialsData, headerData] = await Promise.all([
    getHeroData(),
    getServicesData(),
    getHowData(),
    getAnnouncementsData(),
    getFooterData(),
    getTestimonialsData(),
    getHeaderData()
  ]);

  return (
    <main className="relative overflow-hidden">
      <Header navigationLinks={headerData.navigationLinks} />
      <GradientBackground />
      <Hero data={heroData} />
      <Testimonials data={testimonialsData} />
      <Services data={servicesData} />
      <How data={howData} />
      <Announcements data={announcementsData} />
      <Footer data={footerData} />
    </main>
  );
}