"use client"
import Image from "next/image"
import logo from "@/assets/logo.png"
import { useTheme } from "next-themes"
import { useState, useEffect } from "react"

function LoadingSpinner() {
  const { theme } = useTheme()
  const [mounted, setMounted] = useState(false)
  
  useEffect(() => {
    setMounted(true)
  }, [])
  
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-white/80 dark:bg-[#1F1F23]/80 z-50">
      <div className="relative flex flex-col items-center bg-white dark:bg-[#1F1F23] rounded-md shadow-lg p-5 w-[180px]">
        <Image 
          src={logo} 
          alt="Logo" 
          width={40} 
          height={40} 
          className="mb-3"
        />
        <div className="relative h-12 w-12 mb-1">
          <div className="h-12 w-12 rounded-full border-4 border-gray-200 dark:border-gray-700"></div>
          <div 
            className="absolute top-0 left-0 h-12 w-12 rounded-full border-4 border-blue-500 border-t-transparent animate-spin"
          ></div>
        </div>
      </div>
    </div>
  )
}

export default LoadingSpinner;