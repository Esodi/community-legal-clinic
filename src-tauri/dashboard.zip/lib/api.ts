import { notFound } from 'next/navigation';
import { promises as fs } from 'fs';
import path from 'path';

// Helper to read JSON data
async function readData<T>(filename: string): Promise<T> {
  try {
    const filePath = path.join(process.cwd(), 'app/api', filename);
    const fileContents = await fs.readFile(filePath, 'utf8');
    return JSON.parse(fileContents) as T;
  } catch (error) {
    console.error(`Error reading data file ${filename}:`, error);
    notFound();
  }
}

// Helper to write JSON data
async function writeData(filename: string, data: any): Promise<void> {
  try {
    const filePath = path.join(process.cwd(), 'app/api', filename);
    await fs.writeFile(filePath, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error(`Error writing data file ${filename}:`, error);
    throw new Error('Failed to write data');
  }
}

interface User {
  id: string;
  username: string;
  email: string;
  password: string;
  role: 'admin' | 'user';
  createdAt: string;
}

interface Session {
  username: string;
  token: string;
  role: string;
  lastActive: string;
}

export async function getUsersData() {
  return readData<{ users: User[] }>('users.json');
}

export async function getAuthData() {
  return readData<{ sessions: Session[] }>('auth.json');
}

export async function updateAuthData(data: { sessions: Session[] }) {
  return writeData('auth.json', data);
}

export async function findUserByUsername(username: string): Promise<User | null> {
  const { users } = await getUsersData();
  return users.find(u => u.username === username) || null;
}

export async function getHeaderData() {
  return readData<{
    navigationLinks: Array<{
      id: number;
      label: string;
      href: string;
    }>;
  }>('header.json');
}

export async function getHeroData() {
  return readData<{
    headline: string;
    subheadline: string;
    ctaText: string;
    chatData: {
      userMessage: string;
      botResponse: string;
      userName: string;
      options: Array<{
        id: number;
        text: string;
        icon: 'calendar' | 'chat';
      }>;
    };
  }>('hero.json');
}

export async function getServicesData() {
  return readData<{
    title: string;
    packages: Array<{
      id: number;
      title: string;
      videoThumbnail: string;
      videoUrl: string;
      offerings: Array<{
        id: number;
        text: string;
      }>;
    }>;
  }>('services.json');
}

export async function getHowData() {
  return readData<{
    title: string;
    subtitle: string;
    steps: Array<{
      id: number;
      title: string;
      description: string;
      icon: string;
    }>;
  }>('how.json');
}

export async function getAnnouncementsData() {
  return readData<{
    title: string;
    announcements: Array<{
      id: number;
      title: string;
      description: string;
      date: {
        day: string;
        month: string;
        year: string;
      };
      isNew: boolean;
    }>;
  }>('announcements.json');
}

export async function getFooterData() {
  return readData<{
    aboutUs: {
      title: string;
      description: string;
    };
    contactUs: {
      title: string;
      items: Array<{
        id: number;
        label: string;
        value?: string;
      }>;
    };
    ourServices: {
      title: string;
      items: Array<{
        id: number;
        label: string;
        href: string;
      }>;
    };
    usefulLinks: {
      title: string;
      items: Array<{
        id: number;
        label: string;
        href: string;
      }>;
    };
    socialLinks: Array<{
      id: number;
      platform: string;
      url: string;
      icon: string;
      ariaLabel: string;
    }>;
  }>('footer.json');
}

export async function getTestimonialsData() {
  return readData<{
    title: string;
    subtitle: string;
    testimonials: Array<{
      id: number;
      name: string;
      location: string;
      text: string;
      image: string;
    }>;
  }>('testimonials.json');
}