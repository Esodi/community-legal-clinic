// Check if user is authenticated
export async function checkAuth(): Promise<{ isAuthenticated: boolean; user?: { username: string; role: string } }> {
  try {
    // Check if the client-side cookie exists
    const isClientAuthenticated = document.cookie.includes('isAuthenticated=true');

    // Make the actual server-side check
    const response = await fetch('/api/auth/check', {
      method: 'GET',
      credentials: 'include',
      headers: {
        'Cache-Control': 'no-cache',
      },
    });
    
    if (!response.ok) {
      console.log(`Auth check failed with status: ${response.status}`);
      
      // If the server says we're not authenticated but the client thinks we are,
      // clear the client-side cookie to match the server state
      if (isClientAuthenticated) {
        console.log('Client auth state mismatch with server, clearing client cookies');
        document.cookie = 'isAuthenticated=false; path=/; max-age=0';
      }
      
      return { isAuthenticated: false };
    }

    const data = await response.json();
    
    // If the server says we're authenticated but the client cookie is missing,
    // set the client-side cookie to match the server state
    if (data.isAuthenticated && !isClientAuthenticated) {
      document.cookie = 'isAuthenticated=true; path=/; max-age=86400';
    }
    
    return {
      isAuthenticated: true,
      user: data.user
    };
  } catch (error) {
    console.error('Authentication check error:', error);
    return { isAuthenticated: false };
  }
}

// Get session
export async function getSession(token: string) {
  try {
    const response = await fetch(`/api/auth/session?token=${token}`);
    if (!response.ok) return null;
    return response.json();
  } catch (error) {
    return null;
  }
}

// Remove session
export async function removeSession(username?: string, token?: string) {
  try {
    const params = new URLSearchParams();
    if (username) params.append('username', username);
    if (token) params.append('token', token);
    
    await fetch(`/api/auth/session?${params.toString()}`, {
      method: 'DELETE'
    });
  } catch (error) {
    console.error('Error removing session:', error);
  }
} 