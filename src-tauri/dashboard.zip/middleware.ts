import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

// Define which routes are protected (require authentication)
const protectedRoutes = ['/dashboard', '/profile', '/website']
// Define which routes are public (for non-authenticated users)
const authRoutes = ['/login', '/signup']

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl
  
  // Skip middleware for API routes and other non-app routes
  if (pathname.startsWith('/api') || 
      pathname.startsWith('/_next') ||
      pathname.startsWith('/static') ||
      pathname.startsWith('/favicon.ico') ||
      pathname.startsWith('/public')) {
    return NextResponse.next()
  }
  
  // Check for authentication cookies
  const token = request.cookies.get('token')?.value
  const username = request.cookies.get('username')?.value
  const isAuthenticated = Boolean(token && username)
  
  // Also check for the client-side cookie which might be set
  const isAuthenticatedClient = request.cookies.get('isAuthenticated')?.value === 'true'
  
  const isUserAuthenticated = isAuthenticated || isAuthenticatedClient

  // If trying to access protected route without authentication, redirect to login
  if (protectedRoutes.some(route => pathname.startsWith(route)) && !isUserAuthenticated) {
    const loginUrl = new URL('/login', request.url)
    return NextResponse.redirect(loginUrl)
  }

  // If trying to access auth routes (login/signup) with valid authentication, redirect to dashboard
  if (authRoutes.includes(pathname) && isUserAuthenticated) {
    const dashboardUrl = new URL('/dashboard', request.url)
    return NextResponse.redirect(dashboardUrl)
  }

  return NextResponse.next()
}

// Configure which routes the middleware should run on
export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder
     */
    '/((?!api|_next/static|_next/image|favicon.ico|public).*)',
  ],
} 