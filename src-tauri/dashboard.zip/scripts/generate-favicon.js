import sharp from 'sharp';
import { promises as fs } from 'fs';
import path from 'path';

const sizes = {
  favicon16: 16,
  favicon32: 32,
  apple180: 180
};

async function generateFavicons() {
  const inputFile = './assets/logo.png';
  const publicDir = './public';

  try {
    // Ensure the public directory exists
    await fs.mkdir(publicDir, { recursive: true });

    // Generate favicon.ico (16x16)
    await sharp(inputFile)
      .resize(16, 16)
      .toFile(path.join(publicDir, 'favicon.ico'));

    // Generate PNG favicons
    await sharp(inputFile)
      .resize(sizes.favicon16, sizes.favicon16)
      .toFile(path.join(publicDir, 'favicon-16x16.png'));

    await sharp(inputFile)
      .resize(sizes.favicon32, sizes.favicon32)
      .toFile(path.join(publicDir, 'favicon-32x32.png'));

    // Generate Apple Touch Icon
    await sharp(inputFile)
      .resize(sizes.apple180, sizes.apple180)
      .toFile(path.join(publicDir, 'apple-touch-icon.png'));

    console.log('Favicons generated successfully!');
  } catch (error) {
    console.error('Error generating favicons:', error);
  }
}

generateFavicons(); 