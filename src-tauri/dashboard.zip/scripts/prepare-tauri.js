// scripts/prepare-tauri.js
import { promises as fs } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function main() {
  const rootDir = path.resolve(__dirname, '..');
  const outDir = path.join(rootDir, 'out');
  const nextDir = path.join(rootDir, '.next');
  const staticDir = path.join(nextDir, 'static');

  // Create out directory if it doesn't exist
  try {
    await fs.mkdir(outDir, { recursive: true });
    console.log('Created out directory');
  } catch (err) {
    console.error('Error creating out directory:', err);
  }

  // Copy the static files from .next/static to out/static
  try {
    await copyDir(staticDir, path.join(outDir, 'static'));
    console.log('Copied static files');
  } catch (err) {
    console.error('Error copying static files:', err);
  }

  // Create an index.html file in the out directory
  try {
    const indexHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Community Legal Clinic App</title>
  <script>
    // In a real app, you'd load your actual Next.js assets or provide a fallback experience
    window.location.href = 'http://localhost:3000';
  </script>
</head>
<body>
  <div id="app">
    <h1>Loading Community Legal Clinic App...</h1>
    <p>If this screen doesn't disappear, please make sure the app server is running.</p>
  </div>
</body>
</html>`;
    
    await fs.writeFile(path.join(outDir, 'index.html'), indexHtml);
    console.log('Created index.html');
  } catch (err) {
    console.error('Error creating index.html:', err);
  }

  console.log('Preparation complete!');
}

async function copyDir(src, dest) {
  await fs.mkdir(dest, { recursive: true });
  const entries = await fs.readdir(src, { withFileTypes: true });

  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);

    if (entry.isDirectory()) {
      await copyDir(srcPath, destPath);
    } else {
      await fs.copyFile(srcPath, destPath);
    }
  }
}

main().catch(console.error); 